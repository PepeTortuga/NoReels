package com.facu.noreels

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class BlockerService : AccessibilityService() {

    // IDs de las vistas del reproductor de Reels / Shorts.
    // Pueden cambiar con las actualizaciones de las apps.
    private val targets = mapOf(
        "com.instagram.android" to listOf(
            "com.instagram.android:id/clips_viewer_view_pager",
            "com.instagram.android:id/clips_viewer_container"
        ),
        "com.google.android.youtube" to listOf(
            "com.google.android.youtube:id/reel_recycler",
            "com.google.android.youtube:id/reel_player_page_container"
        )
    )

    private var lastBack = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        // Si el interruptor está apagado, no hace nada
        val prefs = getSharedPreferences("noreels", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", true)) return

        val pkg = event.packageName?.toString() ?: return
        val ids = targets[pkg] ?: return
        val root = rootInActiveWindow ?: return

        if (ids.any { hasVisibleNode(root, it) }) {
            val now = System.currentTimeMillis()
            if (now - lastBack > 800) {
                lastBack = now
                performGlobalAction(GLOBAL_ACTION_BACK)
            }
        }
    }

    private fun hasVisibleNode(root: AccessibilityNodeInfo, id: String): Boolean =
        root.findAccessibilityNodeInfosByViewId(id).any { it.isVisibleToUser }

    override fun onInterrupt() {}
}
