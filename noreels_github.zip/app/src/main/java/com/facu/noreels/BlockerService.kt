package com.facu.noreels

import android.accessibilityservice.AccessibilityService
import android.content.SharedPreferences
import android.os.Build
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class BlockerService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {

    companion object {
        private const val IG = "com.instagram.android"
        private const val YT = "com.google.android.youtube"

        // IDs del reproductor de Reels / Shorts (pueden cambiar con actualizaciones de las apps)
        private val IG_IDS = listOf(
            "com.instagram.android:id/clips_viewer_view_pager",
            "com.instagram.android:id/clips_viewer_container"
        )
        private val YT_IDS = listOf(
            "com.google.android.youtube:id/reel_recycler",
            "com.google.android.youtube:id/reel_player_page_container"
        )

        // Pistas de que estamos dentro de un chat de Instagram
        private val DM_HINTS = listOf("thread_composer", "direct_thread", "direct_text_message", "row_thread")
    }

    private lateinit var prefs: SharedPreferences

    // Ajustes guardados en memoria (no se leen del disco en cada evento)
    @Volatile private var enabled = true
    @Volatile private var allowChat = true

    private var lastProcessed = 0L
    private var lastBack = 0L
    private var lastViewerSeen = 0L
    private var lastDmSeen = 0L
    private var lastDmCheck = 0L
    private var lastYtEvent = 0L
    private var ytSessionStart = 0L
    private var allowedSince = 0L
    private var allowed = false // true mientras se ve el reel permitido (abierto desde un chat)

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = getSharedPreferences("noreels", MODE_PRIVATE)
        loadPrefs()
        prefs.registerOnSharedPreferenceChangeListener(this)
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) = loadPrefs()

    private fun loadPrefs() {
        enabled = prefs.getBoolean("enabled", true)
        allowChat = prefs.getBoolean("allow_chat", true)
    }

    override fun onDestroy() {
        if (::prefs.isInitialized) prefs.unregisterOnSharedPreferenceChangeListener(this)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        if (!enabled) return
        val pkg = event.packageName?.toString() ?: return
        val ids = if (pkg == IG) IG_IDS else if (pkg == YT) YT_IDS else return
        val now = SystemClock.uptimeMillis()

        // Reel permitido: si intentas pasar al siguiente, te devuelve al chat
        if (event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED) {
            if (allowed && now - allowedSince > 1000 && isViewerScroll(event, ids)) {
                allowed = false
                lastDmSeen = 0L
                goBack(now)
            }
            return
        }

        // Limita el trabajo: como máximo ~4 revisiones por segundo
        if (now - lastProcessed < 250) return
        lastProcessed = now

        val root = rootInActiveWindow ?: return
        try {
            if (pkg == YT) {
                if (now - lastYtEvent > 3000) ytSessionStart = now
                lastYtEvent = now
            }

            val viewerVisible = ids.any { hasVisibleNode(root, it) } ||
                (pkg == IG && hasSelectedReelsTab(root))

            if (!viewerVisible) {
                if (now - lastViewerSeen > 1500) allowed = false
                // Instagram: recuerda si hace poco estuvimos en un chat
                if (pkg == IG && allowChat && now - lastDmCheck > 700) {
                    lastDmCheck = now
                    if (containsHint(root)) lastDmSeen = now
                }
                return
            }

            // Si pasó un rato desde el último reel visto, es una sesión nueva
            if (allowed && now - lastViewerSeen > 1500) allowed = false
            lastViewerSeen = now
            if (allowed) return

            if (allowChat) {
                val fromChat = if (pkg == IG) now - lastDmSeen < 3000
                               else now - ytSessionStart < 2500
                if (fromChat) {
                    allowed = true
                    allowedSince = now
                    return
                }
            }

            goBack(now)
        } finally {
            recycle(root)
        }
    }

    private fun goBack(now: Long) {
        if (now - lastBack > 800) {
            lastBack = now
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    private fun isViewerScroll(event: AccessibilityEvent, ids: List<String>): Boolean {
        val src = event.source ?: return false
        try {
            val id = src.viewIdResourceName
            if (id != null && id in ids) return true
            return src.className?.toString()?.contains("ViewPager") == true
        } finally {
            recycle(src)
        }
    }

    private fun hasVisibleNode(root: AccessibilityNodeInfo, id: String): Boolean {
        var found = false
        for (n in root.findAccessibilityNodeInfosByViewId(id)) {
            if (n.isVisibleToUser) found = true
            recycle(n)
        }
        return found
    }

    private fun hasSelectedReelsTab(root: AccessibilityNodeInfo): Boolean {
        var found = false
        for (n in root.findAccessibilityNodeInfosByViewId("com.instagram.android:id/clips_tab")) {
            if (n.isSelected) found = true
            recycle(n)
        }
        return found
    }

    private fun containsHint(node: AccessibilityNodeInfo, depth: Int = 0): Boolean {
        if (depth > 25) return false
        val id = node.viewIdResourceName
        if (id != null && DM_HINTS.any { id.contains(it) }) return true
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = containsHint(child, depth + 1)
            recycle(child)
            if (found) return true
        }
        return false
    }

    @Suppress("DEPRECATION")
    private fun recycle(node: AccessibilityNodeInfo?) {
        if (Build.VERSION.SDK_INT < 33) node?.recycle()
    }

    override fun onInterrupt() {}
}
