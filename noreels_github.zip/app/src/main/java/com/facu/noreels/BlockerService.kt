package com.facu.noreels

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class BlockerService : AccessibilityService() {

    private val instagram = "com.instagram.android"
    private val youtube = "com.google.android.youtube"

    // IDs del reproductor de Reels / Shorts (pueden cambiar con actualizaciones de las apps)
    private val targets = mapOf(
        instagram to listOf(
            "com.instagram.android:id/clips_viewer_view_pager",
            "com.instagram.android:id/clips_viewer_container"
        ),
        youtube to listOf(
            "com.google.android.youtube:id/reel_recycler",
            "com.google.android.youtube:id/reel_player_page_container"
        )
    )

    // Pistas de que estamos dentro de un chat de Instagram
    private val dmHints = listOf("thread_composer", "direct_thread", "direct_text_message", "row_thread")

    private var lastBack = 0L
    private var lastViewerSeen = 0L
    private var lastDmSeen = 0L
    private var lastDmCheck = 0L
    private var lastYtEvent = 0L
    private var ytSessionStart = 0L
    private var allowed = false // true mientras se ve un reel permitido (abierto desde un chat)

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val prefs = getSharedPreferences("noreels", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("enabled", true)) return
        val allowChat = prefs.getBoolean("allow_chat", true)

        val pkg = event.packageName?.toString() ?: return
        val ids = targets[pkg] ?: return
        val root = rootInActiveWindow ?: return
        val now = System.currentTimeMillis()

        // YouTube: detecta cuándo se abrió la app (por ejemplo, desde un enlace recibido)
        if (pkg == youtube) {
            if (now - lastYtEvent > 3000) ytSessionStart = now
            lastYtEvent = now
        }

        val viewerVisible = ids.any { hasVisibleNode(root, it) } ||
            (pkg == instagram && hasSelectedReelsTab(root))

        if (!viewerVisible) {
            if (now - lastViewerSeen > 1500) allowed = false
            // Instagram: recuerda si hace poco estuvimos en un chat
            if (pkg == instagram && allowChat && now - lastDmCheck > 300) {
                lastDmCheck = now
                if (containsHint(root)) lastDmSeen = now
            }
            return
        }

        // Si pasó un rato desde el último reel visto, es una sesión nueva: se vuelve a evaluar
        if (allowed && now - lastViewerSeen > 1500) allowed = false
        lastViewerSeen = now
        if (allowed) return

        if (allowChat) {
            val fromChat = if (pkg == instagram) now - lastDmSeen < 3000
                           else now - ytSessionStart < 2500
            if (fromChat) {
                allowed = true
                return
            }
        }

        if (now - lastBack > 800) {
            lastBack = now
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    private fun hasVisibleNode(root: AccessibilityNodeInfo, id: String): Boolean =
        root.findAccessibilityNodeInfosByViewId(id).any { it.isVisibleToUser }

    private fun hasSelectedReelsTab(root: AccessibilityNodeInfo): Boolean =
        root.findAccessibilityNodeInfosByViewId("com.instagram.android:id/clips_tab")
            .any { it.isSelected }

    private fun containsHint(node: AccessibilityNodeInfo?, depth: Int = 0): Boolean {
        if (node == null || depth > 25) return false
        val id = node.viewIdResourceName
        if (id != null && dmHints.any { id.contains(it) }) return true
        for (i in 0 until node.childCount) {
            if (containsHint(node.getChild(i), depth + 1)) return true
        }
        return false
    }

    override fun onInterrupt() {}
}
