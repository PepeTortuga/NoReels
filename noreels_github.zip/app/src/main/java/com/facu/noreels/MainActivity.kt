package com.facu.noreels

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("noreels", Context.MODE_PRIVATE)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(48, 48, 48, 48)
        }

        layout.addView(TextView(this).apply {
            text = "NoReels bloquea los Reels de Instagram y los Shorts de YouTube."
            textSize = 18f
        })

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, 32, 0, 32)
        }
        layout.addView(status)

        layout.addView(Switch(this).apply {
            text = "Bloqueo activado   "
            textSize = 18f
            isChecked = prefs.getBoolean("enabled", true)
            setPadding(0, 16, 0, 16)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("enabled", checked).apply()
            }
        })

        layout.addView(CheckBox(this).apply {
            text = "Permitir los reels que me envían por chat"
            textSize = 16f
            isChecked = prefs.getBoolean("allow_chat", true)
            setPadding(0, 16, 0, 32)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("allow_chat", checked).apply()
            }
        })

        layout.addView(TextView(this).apply {
            text = "Cómo dar el permiso (solo una vez):\n" +
                "1. Toca \"Abrir accesibilidad\" y entra en NoReels (puede estar en \"Apps instaladas\").\n" +
                "2. Activa el interruptor y acepta el aviso.\n\n" +
                "Si Android dice \"Ajuste restringido\" o no te deja activarlo: toca " +
                "\"Ajustes de la app\", abre el menú ⋮ (arriba a la derecha) y elige " +
                "\"Permitir ajustes restringidos\". Luego vuelve al paso 1."
            textSize = 14f
            setPadding(0, 0, 0, 24)
        })

        layout.addView(Button(this).apply {
            text = "Abrir accesibilidad"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })

        layout.addView(Button(this).apply {
            text = "Ajustes de la app"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:$packageName"))
                )
            }
        })

        setContentView(layout)
    }

    override fun onResume() {
        super.onResume()
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        )?.contains("$packageName/${BlockerService::class.java.name}") == true
        status.text = if (enabled) "✅ Permiso concedido: la app está funcionando"
                      else "❌ Falta el permiso de accesibilidad"
    }
}
