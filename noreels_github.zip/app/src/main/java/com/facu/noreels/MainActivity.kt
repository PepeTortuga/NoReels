package com.facu.noreels

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("noreels", Context.MODE_PRIVATE)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }

        layout.addView(TextView(this).apply {
            text = "NoReels bloquea los Reels de Instagram y los Shorts de YouTube."
            textSize = 18f
        })

        layout.addView(Switch(this).apply {
            text = "Bloqueo activado   "
            textSize = 18f
            isChecked = prefs.getBoolean("enabled", true)
            setPadding(0, 48, 0, 48)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("enabled", checked).apply()
            }
        })

        layout.addView(TextView(this).apply {
            text = "Primero debes dar permiso en Accesibilidad > NoReels (solo una vez)."
            textSize = 14f
        })

        layout.addView(Button(this).apply {
            text = "Abrir ajustes de accesibilidad"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })

        setContentView(layout)
    }
}
